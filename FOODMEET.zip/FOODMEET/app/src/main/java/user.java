/**
 * Created by Aseem on 6/19/2018.
 */

public class user {
    private String name;
    private String email;
    private String pass;
    public user(String uname, String uemail, String upass){
        name = uname;
        email = uemail;
        pass = upass;
    }

    public String getName(){
        return name;
    }

    public String getPass(){
        return pass;
    }
}
