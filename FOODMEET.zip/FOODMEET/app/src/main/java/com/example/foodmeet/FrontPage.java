package com.example.foodmeet;

import android.content.Intent;
import android.os.StrictMode;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class FrontPage extends AppCompatActivity {


    String[] grouplist = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_front_page);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        String username = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        String responsestr = "";
        try{
            String url = "http://aseemapi.us.openode.io/?desiredMethod=GETFOODS&uname=" + username;
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            responsestr = response.toString();

        }
        catch(Exception e){

        }

        grouplist = responsestr.split(",");
        ListView listView = (ListView)findViewById(R.id.dynamicList);
        CustomAdapter customAdapter = new CustomAdapter();
        listView.setAdapter(customAdapter);

    }

    class CustomAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return grouplist.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = getLayoutInflater().inflate(R.layout.frontpage_entry,null);
            ConstraintLayout bar1 = view.findViewById(R.id.bar1);
            ConstraintLayout bar2 = view.findViewById(R.id.bar2);
            ConstraintLayout bar3 = view.findViewById(R.id.bar3);
            ConstraintLayout bar4 = view.findViewById(R.id.bar4);
            ConstraintLayout bar5 = view.findViewById(R.id.bar5);
            bar1.setBackgroundColor(0xff8060);
            bar2.setBackgroundColor(0xff8060);
            bar3.setBackgroundColor(0xff8060);
            bar4.setBackgroundColor(0xff8060);
            bar5.setBackgroundColor(0xff8060);

            TextView groupText = view.findViewById(R.id.groupText);
            TextView placeText = view.findViewById(R.id.placeText);

            groupText.setText(grouplist[position]);



            return view;
        }
    }
}
