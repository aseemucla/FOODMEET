package com.example.foodmeet;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class SignUpScreen extends AppCompatActivity {

    int[][] timesarr = new int[7][24];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_screen);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

    }

    public void clickCheckBox(View view){
        int rb = -1;
        RadioButton tmp = (RadioButton)findViewById(R.id.mondayButton);
        if(tmp.isChecked()){
            rb = 0;
        }
        tmp = (RadioButton)findViewById(R.id.tuesdayButton);
        if(tmp.isChecked()){
            rb = 1;
        }
        tmp = (RadioButton)findViewById(R.id.wednesdayButton);
        if(tmp.isChecked()){
            rb = 2;
        }
        tmp = (RadioButton)findViewById(R.id.thursdayButton);
        if(tmp.isChecked()){
            rb = 3;
        }
        tmp = (RadioButton)findViewById(R.id.fridayButton);
        if(tmp.isChecked()){
            rb = 4;
        }
        tmp = (RadioButton)findViewById(R.id.saturdayButton);
        if(tmp.isChecked()){
            rb = 5;
        }
        tmp = (RadioButton)findViewById(R.id.sundayButton);
        if(tmp.isChecked()){
            rb = 6;
        }

        if(rb != -1){

            switch(view.getId()){
                case(R.id.checkBox0):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][0] = 1;
                    }
                    else{
                        timesarr[rb][0] = 0;
                    }
                    break;
                case(R.id.checkBox1):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][1] = 1;
                    }
                    else{
                        timesarr[rb][1] = 0;
                    }
                    break;
                case(R.id.checkBox2):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][2] = 1;
                    }
                    else{
                        timesarr[rb][2] = 0;
                    }
                    break;
                case(R.id.checkBox3):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][3] = 1;
                    }
                    else{
                        timesarr[rb][3] = 0;
                    }
                    break;
                case(R.id.checkBox4):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][4] = 1;
                    }
                    else{
                        timesarr[rb][4] = 0;
                    }
                    break;
                case(R.id.checkBox5):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][5] = 1;
                    }
                    else{
                        timesarr[rb][5] = 0;
                    }
                    break;
                case(R.id.checkBox6):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][6] = 1;
                    }
                    else{
                        timesarr[rb][6] = 0;
                    }
                    break;
                case(R.id.checkBox7):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][7] = 1;
                    }
                    else{
                        timesarr[rb][7] = 0;
                    }
                    break;
                case(R.id.checkBox8):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][8] = 1;
                    }
                    else{
                        timesarr[rb][8] = 0;
                    }
                    break;
                case(R.id.checkBox9):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][9] = 1;
                    }
                    else{
                        timesarr[rb][9] = 0;
                    }
                    break;
                case(R.id.checkBox10):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][10] = 1;
                    }
                    else{
                        timesarr[rb][10] = 0;
                    }
                    break;
                case(R.id.checkBox11):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][11] = 1;
                    }
                    else{
                        timesarr[rb][11] = 0;
                    }
                    break;
                case(R.id.checkBox12):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][12] = 1;
                    }
                    else{
                        timesarr[rb][12] = 0;
                    }
                    break;
                case(R.id.checkBox13):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][13] = 1;
                    }
                    else{
                        timesarr[rb][13] = 0;
                    }
                    break;
                case(R.id.checkBox14):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][14] = 1;
                    }
                    else{
                        timesarr[rb][14] = 0;
                    }
                    break;
                case(R.id.checkBox15):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][15] = 1;
                    }
                    else{
                        timesarr[rb][15] = 0;
                    }
                    break;
                case(R.id.checkBox16):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][16] = 1;
                    }
                    else{
                        timesarr[rb][16] = 0;
                    }
                    break;
                case(R.id.checkBox17):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][17] = 1;
                    }
                    else{
                        timesarr[rb][17] = 0;
                    }
                    break;
                case(R.id.checkBox18):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][18] = 1;
                    }
                    else{
                        timesarr[rb][18] = 0;
                    }
                    break;
                case(R.id.checkBox19):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][19] = 1;
                    }
                    else{
                        timesarr[rb][19] = 0;
                    }
                    break;
                case(R.id.checkBox20):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][20] = 1;
                    }
                    else{
                        timesarr[rb][20] = 0;
                    }
                    break;
                case(R.id.checkBox21):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][21] = 1;
                    }
                    else{
                        timesarr[rb][21] = 0;
                    }
                    break;
                case(R.id.checkBox22):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][22] = 1;
                    }
                    else{
                        timesarr[rb][22] = 0;
                    }
                    break;
                case(R.id.checkBox23):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][23] = 1;
                    }
                    else{
                        timesarr[rb][23] = 0;
                    }
                    break;

            }
        }
    }



    public void clickRadioButton(View view){
        int rb = -1;
        if(((RadioButton) view).isChecked()){
            if(view.getId() == R.id.mondayButton){
                rb = 0;
            }
            if(view.getId() == R.id.tuesdayButton){
                rb = 1;
            }
            if(view.getId() == R.id.wednesdayButton){
                rb = 2;
            }
            if(view.getId() == R.id.thursdayButton){
                rb = 3;
            }
            if(view.getId() == R.id.fridayButton){
                rb = 4;
            }
            if(view.getId() == R.id.saturdayButton){
                rb = 5;
            }
            if(view.getId() == R.id.sundayButton){
                rb = 6;
            }

            for(int i = 0; i < 24; i++){
                CheckBox curr = null;
                switch(i){
                    case 0:
                        curr = (CheckBox)findViewById(R.id.checkBox0);
                        break;
                    case 1:
                        curr = (CheckBox)findViewById(R.id.checkBox1);
                        break;
                    case 2:
                        curr = (CheckBox)findViewById(R.id.checkBox2);
                        break;
                    case 3:
                        curr = (CheckBox)findViewById(R.id.checkBox3);
                        break;
                    case 4:
                        curr = (CheckBox)findViewById(R.id.checkBox4);
                        break;
                    case 5:
                        curr = (CheckBox)findViewById(R.id.checkBox5);
                        break;
                    case 6:
                        curr = (CheckBox)findViewById(R.id.checkBox6);
                        break;
                    case 7:
                        curr = (CheckBox)findViewById(R.id.checkBox7);
                        break;
                    case 8:
                        curr = (CheckBox)findViewById(R.id.checkBox8);
                        break;
                    case 9:
                        curr = (CheckBox)findViewById(R.id.checkBox9);
                        break;
                    case 10:
                        curr = (CheckBox)findViewById(R.id.checkBox10);
                        break;
                    case 11:
                        curr = (CheckBox)findViewById(R.id.checkBox11);
                        break;
                    case 12:
                        curr = (CheckBox)findViewById(R.id.checkBox12);
                        break;
                    case 13:
                        curr = (CheckBox)findViewById(R.id.checkBox13);
                        break;
                    case 14:
                        curr = (CheckBox)findViewById(R.id.checkBox14);
                        break;
                    case 15:
                        curr = (CheckBox)findViewById(R.id.checkBox15);
                        break;
                    case 16:
                        curr = (CheckBox)findViewById(R.id.checkBox16);
                        break;
                    case 17:
                        curr = (CheckBox)findViewById(R.id.checkBox17);
                        break;
                    case 18:
                        curr = (CheckBox)findViewById(R.id.checkBox18);
                        break;
                    case 19:
                        curr = (CheckBox)findViewById(R.id.checkBox19);
                        break;
                    case 20:
                        curr = (CheckBox)findViewById(R.id.checkBox20);
                        break;
                    case 21:
                        curr = (CheckBox)findViewById(R.id.checkBox21);
                        break;
                    case 22:
                        curr = (CheckBox)findViewById(R.id.checkBox22);
                        break;
                    case 23:
                        curr = (CheckBox)findViewById(R.id.checkBox23);
                        break;
                }

                if(timesarr[rb][i] == 1){
                    curr.setChecked(true);
                }
                else{
                    curr.setChecked(false);
                }
            }
        }
    }

    public void signMeTFUp(View view){
        TextView infoText = (TextView) findViewById(R.id.infoText);
        infoText.setVisibility(View.INVISIBLE);

        EditText userText = (EditText) findViewById(R.id.userText);
        String uname = userText.getText().toString();

        EditText passText = (EditText) findViewById(R.id.passText);
        String upass = passText.getText().toString();

        EditText passText2 = (EditText) findViewById(R.id.passText2);
        String upass2 = passText2.getText().toString();

        EditText emailText = (EditText) findViewById(R.id.emailText);
        String uemail = emailText.getText().toString();


        if(!upass.equals(upass2)){
            infoText.setText("Passwords don't match. Try again.");
            infoText.setVisibility(View.VISIBLE);
            return;
        }


        if(uname.equals("") || upass.equals("") || upass2.equals("") || uemail.equals("")){
            infoText.setText("One or more fields are left blank. Try again.");
            infoText.setVisibility(View.VISIBLE);
            return;
        }


        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);

        try{

            String url = "http://aseemapi.us.openode.io/?desiredMethod=USREXISTS&uname=" + uname;
            URL obj = new URL(url);

            HttpURLConnection con = (HttpURLConnection) obj.openConnection();


            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));

            String inputLine;
            StringBuilder response = new StringBuilder();



            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();


            String responsestr = response.toString();


            if(responsestr.equals("1")) {
                infoText.setText("User already exists. Try again.");
                infoText.setVisibility(View.VISIBLE);
                return;
            }


        }
        catch(Exception e){
            infoText.setText(e + "");
            infoText.setVisibility(View.VISIBLE);
        }

        String uavail = "";
        boolean anyused = false;
        boolean prevused = false;

        for(int i = 0; i < 7; i++){
            switch(i){
                case 0:
                    uavail += 'M';
                    break;
                case 1:
                    uavail += 'T';
                    break;
                case 2:
                    uavail += 'W';
                    break;
                case 3:
                    uavail += 'R';
                    break;
                case 4:
                    uavail += 'F';
                    break;
                case 5:
                    uavail += 'S';
                    break;
                case 6:
                    uavail += 'U';
                    break;
            }
            anyused = false;
            prevused = false;
            for(int j = 0; j < 24; j++){
                if(timesarr[i][j] == 1){
                    anyused = true;
                    if(prevused == false){
                        prevused = true;
                        if(j < 10){
                            uavail += '0';
                            uavail += Integer.toString(j);
                        }
                        else{
                            uavail += Integer.toString(j);
                        }
                        uavail += '-';
                    }
                }
                else{
                    if(prevused == true){
                        prevused = false;
                        if(j < 11){
                            uavail += '0';
                            uavail += Integer.toString(j-1);
                        }
                        else{
                            uavail += Integer.toString(j-1);
                        }
                        uavail += ',';
                    }
                }

            }

            if(prevused == true){
                uavail += Integer.toString(23);
                uavail += ',';
            }
            if(anyused == false){
                uavail += "noone,";
            }
        }
        HttpURLConnection con = null;
        try{
            String url ="http://aseemapi.us.openode.io/?desiredMethod=MAKEUSR&uname=" + uname + "&upass=" + upass + "&uemail=" + uemail + "&uavail=" + uavail;
            URL obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection();

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            String responsestr = response.toString();
            infoText.setText("Success!");
            infoText.setVisibility(View.VISIBLE);

            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);

        }
        catch(Exception e){
            infoText.setText(e + "");
            infoText.setVisibility(View.VISIBLE);
        }
    }

}
