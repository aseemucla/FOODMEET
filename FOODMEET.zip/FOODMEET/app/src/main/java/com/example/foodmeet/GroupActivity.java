package com.example.foodmeet;

import android.content.Intent;
import android.graphics.Color;
import android.os.StrictMode;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GroupActivity extends AppCompatActivity {

    String username = "";
    String groupname = "";
    String usrvotes = "";
    String[] placeslist = null;
    String[] memberlist = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        Intent intent = getIntent();
        username = intent.getStringExtra("str0");
        groupname = intent.getStringExtra("str1");
        String responsestr = "";

        try{
            String url = "http://aseemapi.us.openode.io/?desiredMethod=GETWANTS&ugroup=" + groupname;
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            responsestr = response.toString();

        }
        catch(Exception e){

        }

        placeslist = responsestr.split(",");

        try{
            String url = "http://aseemapi.us.openode.io/?desiredMethod=GROUPUSRS&ugroup=" + groupname;
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            responsestr = response.toString();

        }
        catch(Exception e){

        }

        memberlist = responsestr.split(",");
        List<String> list = new ArrayList<String>(Arrays.asList(memberlist));
        list.remove(username);
        memberlist = list.toArray(new String[0]);

        try{
            String url = "http://aseemapi.us.openode.io/?desiredMethod=GETVOTES&uname=" + username;
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            responsestr = response.toString();

        }
        catch(Exception e){

        }

        usrvotes = responsestr;

        ListView list1 = (ListView)findViewById(R.id.list1);
        CustomAdapter1 customAdapter1 = new CustomAdapter1();
        list1.setAdapter(customAdapter1);

        ListView list2 = (ListView)findViewById(R.id.list2);
        CustomAdapter2 customAdapter2 = new CustomAdapter2();
        list2.setAdapter(customAdapter2);


    }

    class CustomAdapter1 extends BaseAdapter {

        @Override
        public int getCount() {
            return placeslist.length/2 + 1;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(position == placeslist.length/2 && placeslist.length/2 < 10){
                View view = getLayoutInflater().inflate(R.layout.groupuser_end, null);
                view.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view)
                    {
                        view.setBackgroundColor(Color.parseColor("#ddffcc"));
                    }
                });
                return view;
            }


            View view = getLayoutInflater().inflate(R.layout.vote_entry,null);

            TextView placeText = view.findViewById(R.id.placeText);
            placeText.setText(placeslist[2*position]);

            TextView votesText = view.findViewById(R.id.votesText);
            votesText.setText(placeslist[2*position + 1] + "votes");

            Button voteButton  = view.findViewById(R.id.voteButton);
            voteButton.setText(usrvotes + "votes left");

            voteButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view)
                {
                    //DO SOMETHING!
                }
            });

            return view;
        }
    }

    class CustomAdapter2 extends BaseAdapter {

        @Override
        public int getCount() {
            return memberlist.length - 1;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = getLayoutInflater().inflate(R.layout.groupuser_entry,null);

            TextView userText = view.findViewById(R.id.userText);

            userText.setText(memberlist[position+1]);

            return view;
        }
    }
}
