package com.example.foodmeet;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.StrictMode;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GroupActivity extends AppCompatActivity {

    String username = "";
    String groupname = "";
    String usrvotes = "";
    String[] placeslist = null;
    String[] memberlist = null;
    CustomAdapter1 customAdapter1 = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        Intent intent = getIntent();
        username = intent.getStringExtra("str0");
        groupname = intent.getStringExtra("str1");

        final TextView groupnameText = findViewById(R.id.groupnameText);
        groupnameText.setText(groupname);

        String responsestr = "";



        try{
            String url = "http://aseemapi.us.openode.io/?desiredMethod=GETWANTS&ugroup=" + groupname;
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            responsestr = response.toString();

        }
        catch(Exception e){

        }

        placeslist = responsestr.split(",");

        try{
            String url = "http://aseemapi.us.openode.io/?desiredMethod=GROUPUSRS&ufood=" + groupname;
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            responsestr = response.toString();

        }
        catch(Exception e){

        }

        memberlist = responsestr.split(",");
        List<String> list = new ArrayList<String>(Arrays.asList(memberlist));
        list.remove(username);
        memberlist = list.toArray(new String[0]);

        ListView list1 = (ListView)findViewById(R.id.list1);
        View root = list1.getRootView();
        int totalusrs = Integer.parseInt(memberlist[0]);
        if(totalusrs <= 5){
            root.setBackgroundColor(Color.parseColor("#ccffcc"));
        }
        else if(totalusrs <= 10){
            root.setBackgroundColor(Color.parseColor("#ccffff"));
        }
        else if(totalusrs <= 20){
            root.setBackgroundColor(Color.parseColor("#ffffcc"));
        }
        else{
            root.setBackgroundColor(Color.parseColor("#ffb3b3"));
        }




        customAdapter1 = new CustomAdapter1();
        list1.setAdapter(customAdapter1);

        ListView list2 = (ListView)findViewById(R.id.list2);
        CustomAdapter2 customAdapter2 = new CustomAdapter2();
        list2.setAdapter(customAdapter2);

        final ToggleButton wantButton  = findViewById(R.id.toggleButton);


        wantButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view)
            {
                if(!wantButton.isChecked()){
                    String responsestr = "";
                    try{
                        String url = "http://aseemapi.us.openode.io/?desiredMethod=RESETWANT&uname=" + username;
                        URL obj = new URL(url);
                        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
                        con.setRequestMethod("GET");
                        BufferedReader in = new BufferedReader(
                                new InputStreamReader(con.getInputStream()));
                        String inputLine;
                        StringBuffer response = new StringBuffer();

                        while ((inputLine = in.readLine()) != null) {
                            response.append(inputLine);
                        }
                        in.close();

                        responsestr = response.toString();

                    }
                    catch(Exception e){

                    }
                }
                else{
                    String responsestr = "";
                    try{
                        String url = "http://aseemapi.us.openode.io/?desiredMethod=SETWANT&uname=" + username + "&ufood=" + groupname;
                        URL obj = new URL(url);
                        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
                        con.setRequestMethod("GET");
                        BufferedReader in = new BufferedReader(
                                new InputStreamReader(con.getInputStream()));
                        String inputLine;
                        StringBuffer response = new StringBuffer();

                        while ((inputLine = in.readLine()) != null) {
                            response.append(inputLine);
                        }
                        in.close();

                        responsestr = response.toString();

                    }
                    catch(Exception e){

                    }
                }




            }
        });
        try{
            String url = "http://aseemapi.us.openode.io/?desiredMethod=CHECKWANT&uname=" + username + "&ufood=" + groupname;
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            responsestr = response.toString();

        }
        catch(Exception e){

        }

        if(responsestr.equals("1")){
            wantButton.setChecked(true);
        }
        else{
            wantButton.setChecked(false);
        }



    }

    class CustomAdapter1 extends BaseAdapter {

        @Override
        public int getCount() {
            return placeslist.length/2 + 1;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(position == placeslist.length/2 && placeslist.length/2 < 10){
                View view = getLayoutInflater().inflate(R.layout.groupuser_end, null);
                view.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view)
                    {
                        //view.setBackgroundColor(Color.parseColor("#ddffcc"));
                        View promptsView = getLayoutInflater().inflate(R.layout.create_place, null);

                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(view.getContext());

                        // set prompts.xml to alertdialog builder
                        alertDialogBuilder.setView(promptsView);

                        final EditText placeText = (EditText) promptsView
                                .findViewById(R.id.placeText);

                        // set dialog message
                        alertDialogBuilder
                                .setCancelable(false)
                                .setPositiveButton("OK",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog,int id) {
                                                // get user input and set it to result
                                                // edit text
                                                String responsestr = "";
                                                try{
                                                    String url = "http://aseemapi.us.openode.io/?desiredMethod=ADDWANT&ugroup=" + groupname + "&uwant=" + placeText.getText();
                                                    URL obj = new URL(url);
                                                    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
                                                    con.setRequestMethod("GET");
                                                    BufferedReader in = new BufferedReader(
                                                            new InputStreamReader(con.getInputStream()));
                                                    String inputLine;
                                                    StringBuffer response = new StringBuffer();

                                                    while ((inputLine = in.readLine()) != null) {
                                                        response.append(inputLine);
                                                    }
                                                    in.close();

                                                    responsestr = response.toString();


                                                }
                                                catch(Exception e){

                                                }

                                                try{
                                                    String url = "http://aseemapi.us.openode.io/?desiredMethod=GETWANTS&ugroup=" + groupname;
                                                    URL obj = new URL(url);
                                                    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
                                                    con.setRequestMethod("GET");
                                                    BufferedReader in = new BufferedReader(
                                                            new InputStreamReader(con.getInputStream()));
                                                    String inputLine;
                                                    StringBuffer response = new StringBuffer();

                                                    while ((inputLine = in.readLine()) != null) {
                                                        response.append(inputLine);
                                                    }
                                                    in.close();

                                                    responsestr = response.toString();

                                                }
                                                catch(Exception e){

                                                }

                                                placeslist = responsestr.split(",");

                                                customAdapter1.notifyDataSetChanged();

                                            }
                                        })
                                .setNegativeButton("Cancel",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog,int id) {
                                                dialog.cancel();
                                            }
                                        });

                        // create alert dialog
                        AlertDialog alertDialog = alertDialogBuilder.create();

                        // show it
                        alertDialog.show();
                    }
                });
                return view;
            }


            View view = getLayoutInflater().inflate(R.layout.vote_entry,null);

            final TextView placeText = view.findViewById(R.id.placeText);
            placeText.setText(placeslist[2*position]);

            TextView votesText = view.findViewById(R.id.votesText);
            votesText.setText(placeslist[2*position + 1] + " votes");

            final Button voteButton  = view.findViewById(R.id.voteButton);


            voteButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view)
                {
                    String responsestr = "";
                    try{
                        String url = "http://aseemapi.us.openode.io/?desiredMethod=USRVOTE&uname=" + username;
                        URL obj = new URL(url);
                        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
                        con.setRequestMethod("GET");
                        BufferedReader in = new BufferedReader(
                                new InputStreamReader(con.getInputStream()));
                        String inputLine;
                        StringBuffer response = new StringBuffer();

                        while ((inputLine = in.readLine()) != null) {
                            response.append(inputLine);
                        }
                        in.close();

                        responsestr = response.toString();

                    }
                    catch(Exception e){

                    }
                    if(responsestr.equals("-1")){
                        voteButton.setText("No votes");
                    }
                    else{
                        voteButton.setText(responsestr + " votes left");
                    }

                    if(!responsestr.equals("-1")){
                        try{
                            String url = "http://aseemapi.us.openode.io/?desiredMethod=ADDVOTE&ugroup=" + groupname + "&uwant=" + placeText.getText();
                            URL obj = new URL(url);
                            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
                            con.setRequestMethod("GET");
                            BufferedReader in = new BufferedReader(
                                    new InputStreamReader(con.getInputStream()));
                            String inputLine;
                            StringBuffer response = new StringBuffer();

                            while ((inputLine = in.readLine()) != null) {
                                response.append(inputLine);
                            }
                            in.close();

                            responsestr = response.toString();

                        }
                        catch(Exception e){

                        }

                        try{
                            String url = "http://aseemapi.us.openode.io/?desiredMethod=GETWANTS&ugroup=" + groupname;
                            URL obj = new URL(url);
                            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
                            con.setRequestMethod("GET");
                            BufferedReader in = new BufferedReader(
                                    new InputStreamReader(con.getInputStream()));
                            String inputLine;
                            StringBuffer response = new StringBuffer();

                            while ((inputLine = in.readLine()) != null) {
                                response.append(inputLine);
                            }
                            in.close();

                            responsestr = response.toString();

                        }
                        catch(Exception e){

                        }

                        placeslist = responsestr.split(",");

                        customAdapter1.notifyDataSetChanged();


                    }



                }
            });

            return view;
        }
    }

    class CustomAdapter2 extends BaseAdapter {

        @Override
        public int getCount() {
            return memberlist.length - 1;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = getLayoutInflater().inflate(R.layout.groupuser_entry,null);

            TextView userText = view.findViewById(R.id.userText);

            userText.setText(memberlist[position+1]);
            ImageView checkImage = view.findViewById(R.id.checkImage);
            ImageView crossImage = view.findViewById(R.id.crossImage);
            String responsestr = "";
            try{
                String url = "http://aseemapi.us.openode.io/?desiredMethod=CHECKWANT&uname=" + memberlist[position+1] + "&ufood=" + groupname;
                URL obj = new URL(url);
                HttpURLConnection con = (HttpURLConnection) obj.openConnection();
                con.setRequestMethod("GET");
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                responsestr = response.toString();

            }
            catch(Exception e){

            }

            if(responsestr.equals("1")){
                checkImage.setVisibility(view.VISIBLE);
                crossImage.setVisibility(view.INVISIBLE);
            }
            else{

            }

            return view;
        }
    }
}
