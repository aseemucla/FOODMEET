package com.example.foodmeet;

import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GroupActivity extends AppCompatActivity {

    String username = "";
    String groupname = "";
    String[] placeslist = null;
    String[] memberlist = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        Intent intent = getIntent();
        username = intent.getStringExtra("str0");
        groupname = intent.getStringExtra("str1");
        String responsestr = "";

        try{
            String url = "http://aseemapi.us.openode.io/?desiredMethod=GETWANTS&ugroup=" + groupname;
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            responsestr = response.toString();

        }
        catch(Exception e){

        }

        placeslist = responsestr.split(",");
        List<String> list = new ArrayList<String>(Arrays.asList(placeslist));
        list.removeAll(Arrays.asList("null"));
        placeslist = list.toArray(placeslist);

        try{
            String url = "http://aseemapi.us.openode.io/?desiredMethod=GROUPUSRS&ugroup=" + groupname;
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            responsestr = response.toString();

        }
        catch(Exception e){

        }

        memberlist = responsestr.split(",");

        

    }
}
