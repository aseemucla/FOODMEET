package com.example.foodmeet;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.FOODMEET.MESSAGE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public class HttpGetRequest extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... params){
            String responsestr = "";
            try{
                String url = "http://aseemapi.us.openode.io/?desiredMethod=CHECKUSR";
                URL obj = new URL(url);
                HttpURLConnection con = (HttpURLConnection) obj.openConnection();
                con.setDoOutput(true);
                con.setRequestMethod("POST");
                con.setRequestProperty("User-Agent", "Java client");
                //con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                BufferedReader in = new BufferedReader(
                        new InputStreamReader(con.getInputStream()));
                String urlParameters = "uname=" + params[0] + "&upass=" + params[1];
                //byte[] postData = urlParameters.getBytes(StandardCharsets.UTF_8);

                String inputLine;
            /*try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
                wr.write(postData);
            }*/

                OutputStream os = con.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(urlParameters);

                writer.flush();
                writer.close();
                os.close();

                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                responsestr = response.toString();

            }
            catch(Exception e){

            }



            return responsestr;
        }
        @Override
        protected void onPostExecute(String result){
            super.onPostExecute(result);
        }
    }


    public void checkID(View view){
        TextView wrongText = (TextView) findViewById(R.id.wrongText);
        wrongText.setVisibility(View.INVISIBLE);
        EditText userText = (EditText) findViewById(R.id.userText);
        String uname = userText.getText().toString();

        EditText passText = (EditText) findViewById(R.id.passText);
        String upass = passText.getText().toString();

        //StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        //StrictMode.setThreadPolicy(policy);

        HttpGetRequest getRequest = new HttpGetRequest();
        String responsestr = "";
        //Perform the doInBackground method, passing in our url
        try {
            responsestr = getRequest.execute(uname, upass).get();
        }
        catch (Exception e){

        }

        if(responsestr.equals("0")){
            wrongText.setVisibility(View.VISIBLE);
        }
        else if(responsestr.equals("1")){
            Intent intent = new Intent(this, FrontPage.class);
            String message = uname;
            intent.putExtra(EXTRA_MESSAGE, message);
            startActivity(intent);
        }

    }

    public void signUp(View view){
        Intent intent = new Intent(this, SignUpScreen.class);
        startActivity(intent);
    }
}
