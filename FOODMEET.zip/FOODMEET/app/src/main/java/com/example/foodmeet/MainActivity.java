package com.example.foodmeet;

import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.FOODMEET.MESSAGE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }



    public void checkID(View view){
        TextView wrongText = (TextView) findViewById(R.id.wrongText);
        wrongText.setVisibility(View.INVISIBLE);
        EditText userText = (EditText) findViewById(R.id.userText);
        String uname = userText.getText().toString();

        EditText passText = (EditText) findViewById(R.id.passText);
        String upass = passText.getText().toString();

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);

        try{
            String url = "http://aseemapi.us.openode.io/?desiredMethod=CHECKUSR&uname=" + uname + "&upass=" + upass;
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            String responsestr = response.toString();
            if(responsestr.equals("0")){
                wrongText.setVisibility(View.VISIBLE);
            }
            else if(responsestr.equals("1")){
                Intent intent = new Intent(this, FrontPage.class);
                String message = uname;
                intent.putExtra(EXTRA_MESSAGE, message);
                startActivity(intent);
            }
        }
        catch(Exception e){

        }

    }

    public void signUp(View view){
        Intent intent = new Intent(this, SignUpScreen.class);
        startActivity(intent);
    }
}
