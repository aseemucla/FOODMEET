package com.example.foodmeet;

import android.content.Intent;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class SettingsMenu extends AppCompatActivity {
    int[][] timesarr = new int[7][24];
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_menu);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);

        Intent intent = getIntent();
        username = intent.getStringExtra("str0");

        HttpURLConnection con = null;
        String responsestr = "";

        try{
            String url = "http://aseemapi.us.openode.io/?desiredMethod=GETAVAIL&uname=" + username;
            URL obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            responsestr = response.toString();

        }
        catch(Exception e){
        }

        int outer = 0;
        int inner = 0;
        for(int i = 0; i < responsestr.length(); i+=6){
            if((responsestr.charAt(i) + "").equals("M")){
                outer = 0;
            }
            if((responsestr.charAt(i) + "").equals("T")){
                outer = 1;
            }
            if((responsestr.charAt(i) + "").equals("W")){
                outer = 2;
            }
            if((responsestr.charAt(i) + "").equals("R")){
                outer = 3;
            }
            if((responsestr.charAt(i) + "").equals("F")){
                outer = 4;
            }
            if((responsestr.charAt(i) + "").equals("S")){
                outer = 5;
            }
            if((responsestr.charAt(i) + "").equals("U")){
                outer = 6;
            }

            int starttime = 0;
            int endtime = 0;
            try{
                starttime = Integer.parseInt((responsestr.charAt(i+1) + "") + responsestr.charAt(i+2));
                endtime = Integer.parseInt((responsestr.charAt(i+4) + "") + responsestr.charAt(i+5));
            }
            catch(Exception e){
                continue;
            }

            for(int j = starttime; j <= endtime; j++){
                timesarr[outer][j] = 1;
            }


        }

        View currentView = this.findViewById(R.id.mondayButton);

        clickRadioButton(currentView);


    }




    public void clickCheckBox(View view){
        int rb = -1;
        RadioButton tmp = (RadioButton)findViewById(R.id.mondayButton);
        if(tmp.isChecked()){
            rb = 0;
        }
        tmp = (RadioButton)findViewById(R.id.tuesdayButton);
        if(tmp.isChecked()){
            rb = 1;
        }
        tmp = (RadioButton)findViewById(R.id.wednesdayButton);
        if(tmp.isChecked()){
            rb = 2;
        }
        tmp = (RadioButton)findViewById(R.id.thursdayButton);
        if(tmp.isChecked()){
            rb = 3;
        }
        tmp = (RadioButton)findViewById(R.id.fridayButton);
        if(tmp.isChecked()){
            rb = 4;
        }
        tmp = (RadioButton)findViewById(R.id.saturdayButton);
        if(tmp.isChecked()){
            rb = 5;
        }
        tmp = (RadioButton)findViewById(R.id.sundayButton);
        if(tmp.isChecked()){
            rb = 6;
        }

        if(rb != -1){

            switch(view.getId()){
                case(R.id.checkBox0):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][0] = 1;
                    }
                    else{
                        timesarr[rb][0] = 0;
                    }
                    break;
                case(R.id.checkBox1):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][1] = 1;
                    }
                    else{
                        timesarr[rb][1] = 0;
                    }
                    break;
                case(R.id.checkBox2):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][2] = 1;
                    }
                    else{
                        timesarr[rb][2] = 0;
                    }
                    break;
                case(R.id.checkBox3):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][3] = 1;
                    }
                    else{
                        timesarr[rb][3] = 0;
                    }
                    break;
                case(R.id.checkBox4):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][4] = 1;
                    }
                    else{
                        timesarr[rb][4] = 0;
                    }
                    break;
                case(R.id.checkBox5):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][5] = 1;
                    }
                    else{
                        timesarr[rb][5] = 0;
                    }
                    break;
                case(R.id.checkBox6):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][6] = 1;
                    }
                    else{
                        timesarr[rb][6] = 0;
                    }
                    break;
                case(R.id.checkBox7):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][7] = 1;
                    }
                    else{
                        timesarr[rb][7] = 0;
                    }
                    break;
                case(R.id.checkBox8):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][8] = 1;
                    }
                    else{
                        timesarr[rb][8] = 0;
                    }
                    break;
                case(R.id.checkBox9):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][9] = 1;
                    }
                    else{
                        timesarr[rb][9] = 0;
                    }
                    break;
                case(R.id.checkBox10):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][10] = 1;
                    }
                    else{
                        timesarr[rb][10] = 0;
                    }
                    break;
                case(R.id.checkBox11):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][11] = 1;
                    }
                    else{
                        timesarr[rb][11] = 0;
                    }
                    break;
                case(R.id.checkBox12):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][12] = 1;
                    }
                    else{
                        timesarr[rb][12] = 0;
                    }
                    break;
                case(R.id.checkBox13):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][13] = 1;
                    }
                    else{
                        timesarr[rb][13] = 0;
                    }
                    break;
                case(R.id.checkBox14):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][14] = 1;
                    }
                    else{
                        timesarr[rb][14] = 0;
                    }
                    break;
                case(R.id.checkBox15):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][15] = 1;
                    }
                    else{
                        timesarr[rb][15] = 0;
                    }
                    break;
                case(R.id.checkBox16):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][16] = 1;
                    }
                    else{
                        timesarr[rb][16] = 0;
                    }
                    break;
                case(R.id.checkBox17):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][17] = 1;
                    }
                    else{
                        timesarr[rb][17] = 0;
                    }
                    break;
                case(R.id.checkBox18):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][18] = 1;
                    }
                    else{
                        timesarr[rb][18] = 0;
                    }
                    break;
                case(R.id.checkBox19):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][19] = 1;
                    }
                    else{
                        timesarr[rb][19] = 0;
                    }
                    break;
                case(R.id.checkBox20):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][20] = 1;
                    }
                    else{
                        timesarr[rb][20] = 0;
                    }
                    break;
                case(R.id.checkBox21):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][21] = 1;
                    }
                    else{
                        timesarr[rb][21] = 0;
                    }
                    break;
                case(R.id.checkBox22):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][22] = 1;
                    }
                    else{
                        timesarr[rb][22] = 0;
                    }
                    break;
                case(R.id.checkBox23):
                    if(((CheckBox)view).isChecked()){
                        timesarr[rb][23] = 1;
                    }
                    else{
                        timesarr[rb][23] = 0;
                    }
                    break;

            }
        }
    }



    public void clickRadioButton(View view){
        int rb = -1;
        if(((RadioButton) view).isChecked()){
            if(view.getId() == R.id.mondayButton){
                rb = 0;
            }
            if(view.getId() == R.id.tuesdayButton){
                rb = 1;
            }
            if(view.getId() == R.id.wednesdayButton){
                rb = 2;
            }
            if(view.getId() == R.id.thursdayButton){
                rb = 3;
            }
            if(view.getId() == R.id.fridayButton){
                rb = 4;
            }
            if(view.getId() == R.id.saturdayButton){
                rb = 5;
            }
            if(view.getId() == R.id.sundayButton){
                rb = 6;
            }

            for(int i = 0; i < 24; i++){
                CheckBox curr = null;
                switch(i){
                    case 0:
                        curr = (CheckBox)findViewById(R.id.checkBox0);
                        break;
                    case 1:
                        curr = (CheckBox)findViewById(R.id.checkBox1);
                        break;
                    case 2:
                        curr = (CheckBox)findViewById(R.id.checkBox2);
                        break;
                    case 3:
                        curr = (CheckBox)findViewById(R.id.checkBox3);
                        break;
                    case 4:
                        curr = (CheckBox)findViewById(R.id.checkBox4);
                        break;
                    case 5:
                        curr = (CheckBox)findViewById(R.id.checkBox5);
                        break;
                    case 6:
                        curr = (CheckBox)findViewById(R.id.checkBox6);
                        break;
                    case 7:
                        curr = (CheckBox)findViewById(R.id.checkBox7);
                        break;
                    case 8:
                        curr = (CheckBox)findViewById(R.id.checkBox8);
                        break;
                    case 9:
                        curr = (CheckBox)findViewById(R.id.checkBox9);
                        break;
                    case 10:
                        curr = (CheckBox)findViewById(R.id.checkBox10);
                        break;
                    case 11:
                        curr = (CheckBox)findViewById(R.id.checkBox11);
                        break;
                    case 12:
                        curr = (CheckBox)findViewById(R.id.checkBox12);
                        break;
                    case 13:
                        curr = (CheckBox)findViewById(R.id.checkBox13);
                        break;
                    case 14:
                        curr = (CheckBox)findViewById(R.id.checkBox14);
                        break;
                    case 15:
                        curr = (CheckBox)findViewById(R.id.checkBox15);
                        break;
                    case 16:
                        curr = (CheckBox)findViewById(R.id.checkBox16);
                        break;
                    case 17:
                        curr = (CheckBox)findViewById(R.id.checkBox17);
                        break;
                    case 18:
                        curr = (CheckBox)findViewById(R.id.checkBox18);
                        break;
                    case 19:
                        curr = (CheckBox)findViewById(R.id.checkBox19);
                        break;
                    case 20:
                        curr = (CheckBox)findViewById(R.id.checkBox20);
                        break;
                    case 21:
                        curr = (CheckBox)findViewById(R.id.checkBox21);
                        break;
                    case 22:
                        curr = (CheckBox)findViewById(R.id.checkBox22);
                        break;
                    case 23:
                        curr = (CheckBox)findViewById(R.id.checkBox23);
                        break;
                }

                if(timesarr[rb][i] == 1){
                    curr.setChecked(true);
                }
                else{
                    curr.setChecked(false);
                }
            }
        }
    }

    public void signMeTFUp(View view){
        TextView infoText = (TextView) findViewById(R.id.infoText);
        infoText.setVisibility(View.INVISIBLE);

        EditText passText = (EditText) findViewById(R.id.passText);
        String upass = passText.getText().toString();

        EditText passText2 = (EditText) findViewById(R.id.passText2);
        String upass2 = passText2.getText().toString();

        EditText emailText = (EditText) findViewById(R.id.emailText);
        String uemail = emailText.getText().toString();


        if(!upass.equals(upass2)){
            infoText.setText("Passwords don't match. Try again.");
            infoText.setVisibility(View.VISIBLE);
            return;
        }



        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);

        String uavail = "";
        boolean anyused = false;
        boolean prevused = false;

        for(int i = 0; i < 7; i++){
            switch(i){
                case 0:
                    uavail += 'M';
                    break;
                case 1:
                    uavail += 'T';
                    break;
                case 2:
                    uavail += 'W';
                    break;
                case 3:
                    uavail += 'R';
                    break;
                case 4:
                    uavail += 'F';
                    break;
                case 5:
                    uavail += 'S';
                    break;
                case 6:
                    uavail += 'U';
                    break;
            }
            anyused = false;
            prevused = false;
            for(int j = 0; j < 24; j++){
                if(timesarr[i][j] == 1){
                    anyused = true;
                    if(prevused == false){
                        prevused = true;
                        if(j < 10){
                            uavail += '0';
                            uavail += Integer.toString(j);
                        }
                        else{
                            uavail += Integer.toString(j);
                        }
                        uavail += '-';
                    }
                }
                else{
                    if(prevused == true){
                        prevused = false;
                        if(j < 11){
                            uavail += '0';
                            uavail += Integer.toString(j-1);
                        }
                        else{
                            uavail += Integer.toString(j-1);
                        }
                        uavail += ',';
                    }
                }

            }

            if(prevused == true){
                uavail += Integer.toString(23);
                uavail += ',';
            }
            if(anyused == false){
                uavail += "noone,";
            }
        }
        HttpURLConnection con = null;
        try{
            String url ="http://aseemapi.us.openode.io/?desiredMethod=UPDATEUSR";
            URL obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection();
            con.setDoOutput(true);
            con.setRequestMethod("POST");
            //con.setRequestProperty("User-Agent", "Java client");
            con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

            String inputLine;

            String urlParameters = "uname=" + URLEncoder.encode(username, "UTF-8") + "&upass=" + URLEncoder.encode(upass, "UTF-8") + "&uemail=" + URLEncoder.encode(uemail, "UTF-8") + "&uavail=" + URLEncoder.encode(uavail, "UTF-8");
            byte[] postData = urlParameters.getBytes(StandardCharsets.UTF_8);



            try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
                wr.write(postData);
            }

            StringBuilder response = new StringBuilder();
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            String responsestr = response.toString();
            infoText.setText(responsestr);
            infoText.setVisibility(View.VISIBLE);

        }
        catch(Exception e){
            infoText.setText(e + "");
            infoText.setVisibility(View.VISIBLE);
        }
    }
}
