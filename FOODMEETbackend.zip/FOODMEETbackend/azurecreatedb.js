var http = require('http');
var url = require('url')
var mysql = require('mysql2')



/*var con = mysql.createConnection({
  host: "aseemserver.database.windows.net",
  user: 'aseem@aseemserver',
  password: "Secure123",
  database: "mydb",
  insecureAuth: true,
  port: 3306,
  ssl: true
});
*/


var Connection = require('tedious').Connection;  
var config = {  
    userName: 'aseem',  
    password: 'Secure123',  
    server: 'aseemserver.database.windows.net',  
    // If you are on Microsoft Azure, you need this:  
    options: {encrypt: true, database: 'mydb'}  
};  
var con = new Connection(config);  


http.createServer(function (req, res) {
    /*con.connect(function(err) {
      if (err) throw err;
      console.log("Connected!");
      
    
      var sql = "CREATE TABLE users (name VARCHAR(255), pass VARCHAR(255), email VARCHAR(255), avail TEXT, wantfood VARCHAR(255), food0 VARCHAR(255),food1 VARCHAR(255),food2 VARCHAR(255),food3 VARCHAR(255),food4 VARCHAR(255),food5 VARCHAR(255),food6 VARCHAR(255),food7 VARCHAR(255),food8 VARCHAR(255),food9 VARCHAR(255))";
      con.query(sql, function (err, result) {
        if (err) throw err;
        console.log("Table created");
      });
    
    
    });
    
    con.end();*/
    var Request = require('tedious').Request
    con.on('connect', function(err) {  
    // If no error, then good to proceed.  
        console.log("Connected");
                //var sql = "CREATE TABLE foodgroup (main VARCHAR(255), want0 VARCHAR(255), vote0 int, want1 VARCHAR(255), vote1 int, want2 VARCHAR(255), vote2 int, want3 VARCHAR(255), vote3 int, want4 VARCHAR(255), vote4 int, want5 VARCHAR(255), vote5 int, want6 VARCHAR(255), vote6 int, want7 VARCHAR(255), vote7 int, want8 VARCHAR(255), vote8 int, want9 VARCHAR(255), vote9 int);"
      var request = new Request("CREATE TABLE users (name VARCHAR(255), pass VARCHAR(255), email VARCHAR(255), avail TEXT, wantfood VARCHAR(255), food0 VARCHAR(255),food1 VARCHAR(255),food2 VARCHAR(255),food3 VARCHAR(255),food4 VARCHAR(255),food5 VARCHAR(255),food6 VARCHAR(255),food7 VARCHAR(255),food8 VARCHAR(255),food9 VARCHAR(255), friends TEXT)", function(err) {  
         if (err) {  
            console.log(err);}
      })
      //var sql = "CREATE TABLE users (name VARCHAR(255), pass VARCHAR(255), email VARCHAR(255), avail TEXT, wantfood VARCHAR(255), food0 VARCHAR(255),food1 VARCHAR(255),food2 VARCHAR(255),food3 VARCHAR(255),food4 VARCHAR(255),food5 VARCHAR(255),food6 VARCHAR(255),food7 VARCHAR(255),food8 VARCHAR(255),food9 VARCHAR(255))";
      
      con.execSql(request);  
      console.log("made!");
      /*con.query(sql, function (error, result) {
        if (error) throw error;
        console.log("Table created");
      });*/
        
    });  
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end('Hello, werld!');
    
    
}).listen(process.env.PORT || 8080)
