var http = require('http')
var mysql = require('mysql')

var con = mysql.createConnection({
  host: "localhost",
  user: "yourusername",
  password: "yourpassword",
  database: "mydb"
});

var server = http.createServer(function(req, res){
	con.connect(function(err) {
		if (err) throw err;
		console.log("Connected!");
		if(req.method == 'MAKEUSR'){
			var parsed = url.parse(req.url, true);
			var uname = parsed.query.uname;
			var upass = parsed.query.upass;
			var uemail = parsed.query.uemail;
			var sql = "INSERT INTO users (name, pass, email) VALUES ('" + uname + "', '" + upass + "', '" + uemail + "')";
			con.query(sql, function (err, result) {
			  if (err) throw err;
			  console.log("1 record inserted");
			});
		}

		else if(req.method == 'ADDFOOD'){
			var parsed = url.parse(req.url, true);
			var uname = parsed.query.uname;
			
		}
	});
})

server.listen(8000)