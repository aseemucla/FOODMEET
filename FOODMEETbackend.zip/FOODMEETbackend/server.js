var http = require('http')
var mysql = require('mysql')

var con = mysql.createConnection({
  host: "localhost",
  user: "yourusername",
  password: "yourpassword",
  database: "mydb"
});

var server = http.createServer(function(req, res){
	con.connect(function(error) {
		if (error) throw error;
		console.log("Connected!");
		var parsed = url.parse(req.url, true);
		var desiredMethod = parsed.query.desiredMethod;

		if(desiredMethod == 'MAKEUSR'){
			var uname = parsed.query.uname;
			var upass = parsed.query.upass;
			var uemail = parsed.query.uemail;
			var uavail = parsed.query.uavail;
			var sql = "INSERT INTO users (name, pass, email, avail) VALUES ('" + uname + "', '" + upass + "', '" + uemail + "', '" + uavail + "')";
			con.query(sql, function (err, result) {
			  if (err) throw err;
			  console.log("1 record inserted");
			});
			res.end();
		}

		else if(desiredMethod == 'ADDFOOD'){
			var uname = parsed.query.uname;
			var ufood = parsed.query.ufood;
			for(var i = 0; i < 10; i++){
				var sql = "SELECT food" + i + " FROM users WHERE name='" + uname + "'";
				con.query(sql, function (err, result) {
				  if (err) throw err;
				  sql = result;
				});
				var currnull = "{ food" + i + ": 'null'}"; //if there is nothing in the current food slot
				if(JSON.stringify(sql[0]) == currnull){
					sql = "UPDATE users SET food" + i + "='" + ufood + "' WHERE name='" + uname + "'";
					con.query(sql, function (err, result) {
					  if (err) throw err;
					});
					break;
				}
			}	
			res.end();
		}

		else if(desiredMethod == 'SETWANT'){ //it is upto the frontend to make sure that wantfood is set to null again after a certain time
			var uname = parsed.query.uname;
			var ufood = parsed.query.ufood;
			var sql = "UPDATE users SET wantfood='" + ufood + "' WHERE name='" + uname + "'";
			con.query(sql, function (err, result) {
			  if (err) throw err;
			});
			res.end();
		}

		else if(desiredMethod == 'CHECKFREE'){
			var uname = parsed.query.uname;
			var uday = parsed.query.uday;
			var uhour = parsed.query.uhour;
			var ufood = parsed.query.ufood;
			var overalllist = [];
			for(var i = 0; i < 10; i++){
				var sql = "SELECT name FROM users WHERE food" + i + "='" + ufood + "' AND wantfood='null'"; 
				con.query(sql, function (err, result) {
				  if (err) throw err;
				  for(var j = 0; j < result.length; j++){
				  	sql = "SELECT avail FROM users WHERE name='" + result[j].name + "'";
				  	con.query(sql, function (err2, result2) {
					  if (err2) throw err2;
					  var avail = result2[0].avail; //an example avail is "Mnonne,T13-14,15-15,W08-09,R05-06,15-17,F08-09,S09-10,U23-24" where M is monday and so on
					  for(var k = 0; k < avail.length; k++){
					  	if(avail.charAt(k) == uday){
					  		for(var l = k + 1; l < avail.length; l+=6){
					  			if(avail.charAt(l) == 'M' || avail.charAt(l) == 'T' || avail.charAt(l) == 'W' || avail.charAt(l) == 'R' || avail.charAt(l) == 'F' || avail.charAt(l) == 'S' || avail.charAt(l) == 'U'){
					  				break;
					  			}
					  			var starttime = avail.charAt(l) + avail.charAt(l+1);
					  			var endtime = avail.charAt(l+3) + avail.charAt(l+4);
					  			if(+uhour >= +starttime && +uhour <= +endtime ){
					  				overalllist += name;
					  				break;
					  			}
					  		}
					  		break;
					  	}
					  }
					});
				  }
				});
			}
			res.write(overalllist.toString());
			res.end();
		}


		else if(desiredMethod == 'GETFOODS'){
			var uname = parsed.query.uname;
			var sql = "SELECT food0, food1, food2, food3, food4, food5, food6, food7, food8, food9 FROM users WHERE name='" + uname + "'";
		  	con.query(sql, function (err, result) {
		  		res.write(JSON.stringify(result[0])); //also returns nulls, so beware
		  	}
			res.end();
		}
	});
})

server.listen(8000)