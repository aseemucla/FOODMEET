var http = require('http');
var bl = require('bl');
const request = require("request")
var props = {desiredMethod:'GETWANTS', ugroup: 'group11'}
//var props = {desiredMethod:'GETFOODS', uname:'root'}
//var props = {desiredMethod:'CHECKFREE', uday:'M', uhour:"05", ufood:'group2'}
//var props = {desiredMethod:'ADDFOOD', uname:'root', ufood:'group7'}
//var props = {desiredMethod:'MAKEUSR', uname:'reet', upass:'secure', uemail:'eee', uavail:'M01-01,05-06,17-18,Tnoone,Wnoone,R05-06,Fnoone,Snoone,Unoone'}

request.get({url: "http://aseemapi.us.openode.io/", qs: props}, function(err, response, body) {
	var str3 = "";
	response.pipe(bl(function (err, dataa) { 
		str3 += dataa.toString();
		console.log(str3);
	}))

	console.log(response)
	response.on("end", function(){
		console.log("YEET")
	})
})