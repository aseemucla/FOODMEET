var http = require('http');
var bl = require('bl');
const request = require("request")

var props = {desiredMethod:'CHECKFREE', uday:'M', uhour: '3', ufood:'group1'}

request.get({url: "http://aseemapi.us.openode.io/", qs: props}, function(err, response, body) {
	var str3 = "";
	response.pipe(bl(function (err, dataa) { 
		str3 += dataa.toString();
		console.log(str3);
	}))

	console.log(response)
	response.on("end", function(){
		console.log("YEET")
	})
})