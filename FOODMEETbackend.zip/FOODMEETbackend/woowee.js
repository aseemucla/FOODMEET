var http = require('http');


http.get('http://foodmeetapi.azurewebsites.net', function yeet(response){
	console.log(response)

	response.on("end", function(){
		console.log("YEET")
	})
})