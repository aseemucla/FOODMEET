#!/usr/bin/env node

const http = require("http");
var mysql = require('mysql2')
var sync = require('synchronize');
var fiber = sync.fiber;
var await = sync.await;
var defer = sync.defer;


/*var con = mysql.createConnection({
  host: "aseemserver.database.windows.net",
  user: 'aseem@aseemserver',
  password: "Secure123",
  database: "mydb",
  insecureAuth: true,
  port: 3306,
  ssl: true
});
*/


var Connection = require('tedious').Connection;  
var config = {  
    userName: 'aseem',  
    password: 'Secure123',  
    server: 'aseemserver.database.windows.net',  
    // If you are on Microsoft Azure, you need this:  
    options: {encrypt: true, database: 'mydb'}  
};  
var con = new Connection(config);  

http.createServer(function (req, res) {
	//res.end("Hello pretty eNode World!");
	var Request = require('tedious').Request
  try {
    fiber(function() {
      var obj1 = await( con.on('connect', defer()));
      var obj2 = await( function(obj1) {  
        // If no error, then good to proceed.  
            //console.log("Connected");
              
          res.end();
            
        }); 
    });
  } catch(err) {
      //TODO Handle error
  }
    /*con.on('connect', function(err) {  
    // If no error, then good to proceed.  
        //console.log("Connected");
          
    	res.end();
        
    });*/
    res.end();
     
}).listen(process.env.PORT || 80)

