#!/usr/bin/env node

const http = require("http");
var mysql = require("mysql2")
var Connection = require('tedious').Connection;  
var config = {  
    userName: 'aseem',  
    password: 'Secure123',  
    server: 'aseemserver.database.windows.net',  
    // If you are on Microsoft Azure, you need this:  
    options: {encrypt: true, database: 'mydb'}  
};  
var con = new Connection(config);

var pubreq;
var pubres;

var server = http.createServer(function (req, res) {
  pubreq = req;
  pubres = res;
	/*con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
    
  
    var sql = "CREATE TABLE users (name VARCHAR(255), pass VARCHAR(255), email VARCHAR(255), avail TEXT, wantfood VARCHAR(255), food0 VARCHAR(255),food1 VARCHAR(255),food2 VARCHAR(255),food3 VARCHAR(255),food4 VARCHAR(255),food5 VARCHAR(255),food6 VARCHAR(255),food7 VARCHAR(255),food8 VARCHAR(255),food9 VARCHAR(255))";
    con.query(sql, function (err, result) {
      if (err) throw err;
      console.log("Table created");
    });
  
  
  });
  
  con.end();*/
  //res.end('Hello, werld!');
  var Request = require('tedious').Request
  con.on('connect', function(err) {
    if (err) throw err;
    console.log("Connected!");
        
    var request = new Request("SELECT pass, name FROM users", function(err) {  
       if (err) {  
          console.log(err);}
          else{
            console.log("WEW")
          }
    })
    //var sql = "CREATE TABLE users (name VARCHAR(255), pass VARCHAR(255), email VARCHAR(255), avail TEXT, wantfood VARCHAR(255), food0 VARCHAR(255),food1 VARCHAR(255),food2 VARCHAR(255),food3 VARCHAR(255),food4 VARCHAR(255),food5 VARCHAR(255),food6 VARCHAR(255),food7 VARCHAR(255),food8 VARCHAR(255),food9 VARCHAR(255))";
    var ress = "";
    request.on('row', function(columns) {  
      var count = 0;
            columns.forEach(function(column) {
               
              if (count == 0) {  
                console.log('NULL');  
              } else {  
                ress+= column.value + " " + column.key;  
              }
              count++;  
            });  
            //console.log(ress);  
            console.log(ress);
            ress ="";  
    })
    
     request.on('doneInProc', function(rowCount, moore, roows){
        console.log("YEE");
        con.end();
        pubres.end("YEEET")
        //res.end();
      });
     pubres.end("YEEET")
     con.execSql(request)
    //pubres.end("YEEET")
    
    
  });  
  //res.writeHead(200, { 'Content-Type': 'text/html' });
  //res.end('Hello, werld!');
  
})

server.listen(80, (err) => {
	if ( ! err) {
		console.log(`server is listening on 80`)
	}
})

