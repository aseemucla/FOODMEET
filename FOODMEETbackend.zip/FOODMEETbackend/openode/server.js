#!/usr/bin/env node

const http = require("http");



var url = require('url')
var mysql = require('mysql2')



/*var con = mysql.createConnection({
  host: "aseemserver.database.windows.net",
  user: 'aseem@aseemserver',
  password: "Secure123",
  database: "mydb",
  insecureAuth: true,
  port: 3306,
  ssl: true
});
*/


var Connection = require('tedious').Connection;  
var config = {  
    userName: 'aseem',  
    password: 'Secure123',  
    server: 'aseemserver.database.windows.net',  
    // If you are on Microsoft Azure, you need this:  
    options: {encrypt: true, database: 'mydb'}  
};  
var con = new Connection(config);  



const server = http.createServer(function (req, res) {
	//res.end("Hello pretty opeNode World!");
	/*con.connect(function(err) {
      if (err) throw err;
      console.log("Connected!");
      
    
      var sql = "CREATE TABLE users (name VARCHAR(255), pass VARCHAR(255), email VARCHAR(255), avail TEXT, wantfood VARCHAR(255), food0 VARCHAR(255),food1 VARCHAR(255),food2 VARCHAR(255),food3 VARCHAR(255),food4 VARCHAR(255),food5 VARCHAR(255),food6 VARCHAR(255),food7 VARCHAR(255),food8 VARCHAR(255),food9 VARCHAR(255))";
      con.query(sql, function (err, result) {
        if (err) throw err;
        console.log("Table created");
      });
    
    
    });
    
    con.end();*/
    var Request = require('tedious').Request
    con.on('connect', function(err) {  
    // If no error, then good to proceed.  
        console.log("Connected");
          
      var request = new Request("SELECT pass, name FROM users", function(err) {  
         if (err) {  
            console.log(err);}
      })
      //var sql = "CREATE TABLE users (name VARCHAR(255), pass VARCHAR(255), email VARCHAR(255), avail TEXT, wantfood VARCHAR(255), food0 VARCHAR(255),food1 VARCHAR(255),food2 VARCHAR(255),food3 VARCHAR(255),food4 VARCHAR(255),food5 VARCHAR(255),food6 VARCHAR(255),food7 VARCHAR(255),food8 VARCHAR(255),food9 VARCHAR(255))";
      var ress = "";
      request.on('row', function(columns) {  
        
        var count = 0;
            columns.forEach(function(column) {
               
              if (count == 0) {  
                console.log('NULL');  
              } else {  
                ress+= column.value + " " + column.key;  
              }
              count++;  
            });  
            //console.log(ress);  
            res.write(ress);
            ress ="";  
      });
       
      
      request.on('doneInProc', function(rowCount, moore, roows){
        console.log("YEE");
        res.end();
      });
      con.execSql(request);  
      console.log("made!");
      /*con.query(sql, function (error, result) {
        if (error) throw error;
        console.log("Table created");
      });*/
        
    });  
    res.writeHead(200, { 'Content-Type': 'text/html' });
})

server.listen(80, (err) => {
	if ( ! err) {
		console.log(`server is listening on 80`)
	}
})


