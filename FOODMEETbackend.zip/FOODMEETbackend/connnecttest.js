var http = require('http');
var bl = require('bl');
const request = require("request")
var props = {}

request.get({url: "http://apimicroservicefh-zimacmpuly.now.sh/", qs: props}, function(err, response, body) {
	var str3 = "";
	response.pipe(bl(function (err, dataa) { 
		str3 += dataa.toString();
		console.log(str3);
	}))

	console.log(response)
	response.on("end", function(){
		console.log("YEET")
	})
})